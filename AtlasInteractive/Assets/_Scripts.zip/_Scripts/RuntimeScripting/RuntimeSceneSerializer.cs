using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using UnityEngine;

public sealed class RuntimeSceneSerializer : MonoBehaviour
{
    [SerializeField] private RuntimeSceneRegistry _sceneRegistry;
    [SerializeField] private RuntimeAssetService _assetService;

    private string _sceneDirectory;

    private void Awake()
    {
        if (_sceneRegistry == null)
        {
            throw new InvalidOperationException("RuntimeSceneRegistry is required.");
        }

        if (_assetService == null)
        {
            throw new InvalidOperationException("RuntimeAssetService is required.");
        }

        _sceneDirectory = Path.Combine(Application.persistentDataPath, "Scenes");

        Directory.CreateDirectory(_sceneDirectory);
    }

    public string Save(string fileName)
    {
        RuntimeSceneData sceneData = new RuntimeSceneData();

        foreach (RuntimeSceneObject obj in _sceneRegistry.Objects)
        {
            RuntimeObjectData objectData = new RuntimeObjectData
            {
                id = obj.Id,
                name = obj.name,
                kind = obj.Kind.ToString(),
                source = obj.Source,
                textureSource = obj.TextureSource,
                audioSource = obj.AudioSourcePath,
                position = obj.transform.localPosition,
                rotation = obj.transform.localRotation,
                scale = obj.transform.localScale
            };

            RuntimeSceneObject parent =
                obj.transform.parent != null
                    ? obj.transform.parent.GetComponent<RuntimeSceneObject>()
                    : null;

            objectData.parentId = parent != null ? parent.Id : "";

            foreach (LuaBehaviour script in obj.GetComponents<LuaBehaviour>())
            {
                objectData.scripts.Add(script.ScriptName);
            }

            Rigidbody rigidbody = obj.GetComponent<Rigidbody>();

            if (rigidbody != null)
            {
                objectData.components.Add(new RuntimeComponentData
                {
                    type = "Rigidbody",
                    mass = rigidbody.mass,
                    useGravity = rigidbody.useGravity,
                    isKinematic = rigidbody.isKinematic
                });
            }

            Light light = obj.GetComponent<Light>();

            if (light != null)
            {
                objectData.components.Add(new RuntimeComponentData
                {
                    type = "Light",
                    intensity = light.intensity,
                    range = light.range,
                    color = light.color
                });
            }

            AudioSource audioSource = obj.GetComponent<AudioSource>();

            if (audioSource != null)
            {
                objectData.components.Add(new RuntimeComponentData
                {
                    type = "AudioSource",
                    volume = audioSource.volume,
                    loop = audioSource.loop,
                    spatialBlend = audioSource.spatialBlend,
                    wasPlaying = audioSource.isPlaying
                });
            }

            sceneData.objects.Add(objectData);
        }

        string path = GetScenePath(fileName);

        File.WriteAllText(
            path,
            JsonUtility.ToJson(sceneData, true)
        );

        Debug.Log($"Scene saved: {path}");

        return path;
    }

    public async Task LoadAsync(string fileName)
    {
        string path = GetScenePath(fileName);

        if (!File.Exists(path))
        {
            throw new FileNotFoundException($"Scene not found: {path}");
        }

        RuntimeSceneData sceneData =
            JsonUtility.FromJson<RuntimeSceneData>(File.ReadAllText(path));

        if (sceneData == null)
        {
            throw new InvalidDataException($"Invalid scene file: {path}");
        }

        _sceneRegistry.Clear();

        await Task.Yield();

        foreach (RuntimeObjectData objectData in sceneData.objects)
        {
            RuntimeObjectKind kind = Enum.Parse<RuntimeObjectKind>(objectData.kind);

            RuntimeSceneObject runtimeObject;

            switch (kind)
            {
                case RuntimeObjectKind.Primitive:
                    {
                        PrimitiveType primitiveType = Enum.Parse<PrimitiveType>(objectData.source);

                        runtimeObject = _sceneRegistry.SpawnPrimitive(
                            objectData.id,
                            objectData.name,
                            primitiveType,
                            objectData.position
                        );

                        break;
                    }

                case RuntimeObjectKind.Model:
                    {
                        await _assetService.LoadModel(
                            objectData.source,
                            objectData.name,
                            objectData.position,
                            objectData.id
                        );

                        runtimeObject = _sceneRegistry.Get(objectData.id);

                        break;
                    }

                default:
                    throw new NotSupportedException($"Unsupported runtime object kind '{kind}'.");
            }

            runtimeObject.transform.localPosition = objectData.position;
            runtimeObject.transform.localRotation = objectData.rotation;
            runtimeObject.transform.localScale = objectData.scale;

            if (!string.IsNullOrWhiteSpace(objectData.textureSource))
            {
                _assetService.ApplyTexture(
                    objectData.id,
                    objectData.textureSource
                );
            }

            foreach (RuntimeComponentData component in objectData.components)
            {
                RestoreComponent(runtimeObject, component);
            }

            if (!string.IsNullOrWhiteSpace(objectData.audioSource))
            {
                RuntimeComponentData audioData =
                    objectData.components.Find(c => c.type == "AudioSource");

                bool loop = audioData != null && audioData.loop;
                float volume = audioData != null ? audioData.volume : 1f;
                bool play = audioData != null && audioData.wasPlaying;

                _assetService.ApplyAudio(
                    objectData.id,
                    objectData.audioSource,
                    play,
                    loop,
                    volume
                );

                AudioSource audioSource = runtimeObject.GetComponent<AudioSource>();

                if (audioSource != null && audioData != null)
                {
                    audioSource.spatialBlend = audioData.spatialBlend;
                }
            }

            foreach (string scriptName in objectData.scripts)
            {
                LuaBehaviour behaviour =
                    runtimeObject.gameObject.AddComponent<LuaBehaviour>();

                behaviour.Configure(
                    scriptName,
                    _sceneRegistry,
                    this
                );
            }
        }

        foreach (RuntimeObjectData objectData in sceneData.objects)
        {
            RuntimeSceneObject runtimeObject = _sceneRegistry.Get(objectData.id);

            if (runtimeObject == null) continue;

            if (!string.IsNullOrWhiteSpace(objectData.parentId))
            {
                _sceneRegistry.SetParent(
                    objectData.id,
                    objectData.parentId
                );
            }

            runtimeObject.transform.localPosition = objectData.position;
            runtimeObject.transform.localRotation = objectData.rotation;
            runtimeObject.transform.localScale = objectData.scale;
        }

        Debug.Log($"Scene loaded: {path}");
    }

    private static void RestoreComponent(RuntimeSceneObject runtimeObject, RuntimeComponentData data)
    {
        switch (data.type)
        {
            case "Rigidbody":
                {
                    Rigidbody rigidbody =
                        runtimeObject.GetComponent<Rigidbody>() ??
                        runtimeObject.gameObject.AddComponent<Rigidbody>();

                    rigidbody.mass = data.mass;
                    rigidbody.useGravity = data.useGravity;
                    rigidbody.isKinematic = data.isKinematic;

                    break;
                }

            case "Light":
                {
                    Light light =
                        runtimeObject.GetComponent<Light>() ??
                        runtimeObject.gameObject.AddComponent<Light>();

                    light.intensity = data.intensity;
                    light.range = data.range;
                    light.color = data.color;

                    break;
                }

            case "AudioSource":
                {
                    AudioSource source =
                        runtimeObject.GetComponent<AudioSource>() ??
                        runtimeObject.gameObject.AddComponent<AudioSource>();

                    source.volume = data.volume;
                    source.loop = data.loop;
                    source.spatialBlend = data.spatialBlend;

                    break;
                }
        }
    }

    private string GetScenePath(string fileName)
    {
        if (Path.GetFileName(fileName) != fileName)
        {
            throw new ArgumentException("Scene file name cannot contain a directory path.");
        }

        if (!fileName.EndsWith(".json", StringComparison.OrdinalIgnoreCase))
        {
            fileName += ".json";
        }

        return Path.Combine(_sceneDirectory, fileName);
    }
}

[Serializable]
public sealed class RuntimeSceneData
{
    public List<RuntimeObjectData> objects = new();
}

[Serializable]
public sealed class RuntimeObjectData
{
    public string id;
    public string name;
    public string kind;
    public string source;
    public string textureSource;
    public string audioSource;
    public string parentId;

    public Vector3 position;
    public Quaternion rotation;
    public Vector3 scale;

    public List<string> scripts = new();
    public List<RuntimeComponentData> components = new();
}

[Serializable]
public sealed class RuntimeComponentData
{
    public string type;

    public float mass;
    public bool useGravity;
    public bool isKinematic;

    public float intensity;
    public float range;
    public Color color;

    public float volume;
    public bool loop;
    public float spatialBlend;
    public bool wasPlaying;
}