using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;

public sealed class RuntimeToolService : MonoBehaviour
{
    [SerializeField] private RuntimeSceneRegistry _sceneRegistry;
    [SerializeField] private RuntimeSceneSerializer _sceneSerializer;
    [SerializeField] private RuntimeAssetService _assetService;
    [SerializeField] private RuntimeFileService _fileService;

    private void Awake()
    {
        if (_sceneRegistry == null) throw new InvalidOperationException("RuntimeSceneRegistry is required.");
        if (_sceneSerializer == null) throw new InvalidOperationException("RuntimeSceneSerializer is required.");
        if (_assetService == null) throw new InvalidOperationException("RuntimeAssetService is required.");
        if (_fileService == null) throw new InvalidOperationException("RuntimeFileService is required.");
    }

    public string CreateCube(string name, float x, float y, float z)
    {
        return _sceneRegistry.SpawnCube(name, new Vector3(x, y, z));
    }

    public string CreatePrimitive(string primitiveType, string name, float x, float y, float z)
    {
        PrimitiveType type = Enum.Parse<PrimitiveType>(primitiveType, true);

        return _sceneRegistry.SpawnPrimitive(
            name,
            type,
            new Vector3(x, y, z)
        ).Id;
    }

    public async Task<string> LoadModel(string path, string name, float x, float y, float z)
    {
        path = NormalizeAssetPath(path);

        return await _assetService.LoadModel(
            path,
            name,
            new Vector3(x, y, z)
        );
    }

    public string[] ListModels()
    {
        return ListAssetFiles("Models", "*.glb");
    }

    public string[] ListTextures()
    {
        return ListAssetFiles("Textures", "*.png");
    }

    public string[] ListAudio()
    {
        return ListAssetFiles("Audio", "*.wav");
    }

    public void SetPosition(string id, float x, float y, float z)
    {
        RequireObject(id).transform.position = new Vector3(x, y, z);
    }

    public void SetRotation(string id, float x, float y, float z)
    {
        RequireObject(id).transform.eulerAngles = new Vector3(x, y, z);
    }

    public void SetScale(string id, float x, float y, float z)
    {
        RequireObject(id).transform.localScale = new Vector3(x, y, z);
    }

    public void RenameObject(string id, string name)
    {
        RequireObject(id).name = name;
    }

    public void SetParent(string childId, string parentId)
    {
        RequireObject(childId);

        if (!string.IsNullOrWhiteSpace(parentId))
        {
            RequireObject(parentId);
        }

        _sceneRegistry.SetParent(childId, parentId);
    }

    public void DestroyObject(string id)
    {
        RuntimeSceneObject runtimeObject = RequireObject(id);

        UnityEngine.Object.Destroy(runtimeObject.gameObject);
    }

    public void SetTexture(string id, string path)
    {
        RequireObject(id);

        path = NormalizeAssetPath(path);

        _assetService.ApplyTexture(id, path);
    }

    public void PlayAudio(string id, string path, bool loop, float volume)
    {
        RequireObject(id);

        path = NormalizeAssetPath(path);

        _assetService.ApplyAudio(
            id,
            path,
            true,
            loop,
            volume
        );
    }

    public string AddComponent(string id, string componentType)
    {
        RuntimeSceneObject runtimeObject = RequireObject(id);

        Component component =
            RuntimeComponentUtility.Add(
                runtimeObject.gameObject,
                componentType
            );

        return component.GetType().Name;
    }

    public void SetComponentProperty(string id, string componentType, string property, string value)
    {
        RuntimeSceneObject runtimeObject = RequireObject(id);

        RuntimeComponentUtility.SetProperty(
            runtimeObject.gameObject,
            componentType,
            property,
            value
        );
    }

    public string SaveScene(string fileName)
    {
        return _sceneSerializer.Save(fileName);
    }

    public async Task LoadScene(string fileName)
    {
        await _sceneSerializer.LoadAsync(fileName);
    }

    public string ReadFile(string path)
    {
        return _fileService.ReadText(path);
    }

    public void WriteFile(string path, string content)
    {
        _fileService.WriteText(path, content);
    }

    public string[] FindFiles(string pattern)
    {
        return _fileService.Find(pattern);
    }

    public void CreateScript(string scriptName, string source)
    {
        scriptName = NormalizeScriptName(scriptName);

        if (string.IsNullOrWhiteSpace(source))
        {
            throw new ArgumentException("Lua source cannot be empty.");
        }

        _fileService.WriteText(
            $"Scripts/{scriptName}",
            source
        );
    }

    public void AttachScript(string objectId, string scriptName)
    {
        RuntimeSceneObject runtimeObject = RequireObject(objectId);

        scriptName = NormalizeScriptName(scriptName);

        string scriptPath = $"Scripts/{scriptName}";

        if (!_fileService.Exists(scriptPath))
        {
            throw new FileNotFoundException(
                $"Lua script does not exist. Call script.create first: {scriptPath}"
            );
        }

        foreach (LuaBehaviour existing in runtimeObject.GetComponents<LuaBehaviour>())
        {
            if (existing.ScriptName != scriptName) continue;

            existing.ReloadNow();
            return;
        }

        LuaBehaviour behaviour =
            runtimeObject.gameObject.AddComponent<LuaBehaviour>();

        try
        {
            behaviour.Configure(
                scriptName,
                _sceneRegistry,
                _sceneSerializer
            );
        }
        catch
        {
            UnityEngine.Object.Destroy(behaviour);
            throw;
        }
    }

    public void CreateAndAttachScript(string objectId, string scriptName, string source)
    {
        RequireObject(objectId);

        scriptName = NormalizeScriptName(scriptName);

        CreateScript(scriptName, source);
        AttachScript(objectId, scriptName);
    }

    public string GetSceneState()
    {
        RuntimeSceneState state = new RuntimeSceneState();

        foreach (RuntimeSceneObject obj in _sceneRegistry.Objects)
        {
            RuntimeObjectState objectState = new RuntimeObjectState
            {
                id = obj.Id,
                name = obj.name,
                kind = obj.Kind.ToString(),
                source = obj.Source,
                textureSource = obj.TextureSource,
                audioSource = obj.AudioSourcePath,
                position = obj.transform.position,
                rotation = obj.transform.eulerAngles,
                scale = obj.transform.localScale
            };

            RuntimeSceneObject parent =
                obj.transform.parent != null
                    ? obj.transform.parent.GetComponent<RuntimeSceneObject>()
                    : null;

            objectState.parentId =
                parent != null
                    ? parent.Id
                    : "";

            foreach (LuaBehaviour script in obj.GetComponents<LuaBehaviour>())
            {
                objectState.scripts.Add(script.ScriptName);
            }

            if (obj.GetComponent<Rigidbody>() != null)
            {
                objectState.components.Add("Rigidbody");
            }

            if (obj.GetComponent<Light>() != null)
            {
                objectState.components.Add("Light");
            }

            if (obj.GetComponent<AudioSource>() != null)
            {
                objectState.components.Add("AudioSource");
            }

            state.objects.Add(objectState);
        }

        return JsonUtility.ToJson(state, true);
    }

    private string[] ListAssetFiles(string directoryName, string searchPattern)
    {
        string directory = Path.Combine(
            _assetService.SourceRoot,
            directoryName
        );

        if (!Directory.Exists(directory))
        {
            return Array.Empty<string>();
        }

        return Directory.GetFiles(
                directory,
                searchPattern,
                SearchOption.AllDirectories
            )
            .Select(path =>
                Path.GetRelativePath(
                    _assetService.SourceRoot,
                    path
                ).Replace('\\', '/')
            )
            .OrderBy(path => path)
            .ToArray();
    }

    private RuntimeSceneObject RequireObject(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
        {
            throw new ArgumentException("Runtime object ID cannot be empty.");
        }

        RuntimeSceneObject runtimeObject =
            _sceneRegistry.Get(id);

        if (runtimeObject == null)
        {
            throw new InvalidOperationException($"Runtime object not found: {id}");
        }

        return runtimeObject;
    }

    private static string NormalizeScriptName(string scriptName)
    {
        if (string.IsNullOrWhiteSpace(scriptName))
        {
            throw new ArgumentException("Script name cannot be empty.");
        }

        return scriptName.EndsWith(".lua", StringComparison.OrdinalIgnoreCase)
            ? scriptName
            : scriptName + ".lua";
    }

    private static string NormalizeAssetPath(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            throw new ArgumentException("Asset path cannot be empty.");
        }

        path = path.Trim().Replace('\\', '/');

        while (path.StartsWith("./", StringComparison.Ordinal))
        {
            path = path.Substring(2);
        }

        path = path.TrimStart('/');

        if (path.StartsWith("Assets/src/", StringComparison.OrdinalIgnoreCase))
        {
            path = path.Substring("Assets/src/".Length);
        }
        else if (path.StartsWith("src/", StringComparison.OrdinalIgnoreCase))
        {
            path = path.Substring("src/".Length);
        }

        return path;
    }
}

[Serializable]
public sealed class RuntimeSceneState
{
    public List<RuntimeObjectState> objects = new();
}

[Serializable]
public sealed class RuntimeObjectState
{
    public string id;
    public string name;
    public string kind;
    public string source;
    public string textureSource;
    public string audioSource;
    public string parentId;

    public Vector3 position;
    public Vector3 rotation;
    public Vector3 scale;

    public List<string> scripts = new();
    public List<string> components = new();
}