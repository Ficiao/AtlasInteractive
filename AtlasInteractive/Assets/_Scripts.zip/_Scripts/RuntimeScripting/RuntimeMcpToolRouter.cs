using System;
using System.IO;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;

public sealed class RuntimeMcpToolRouter : MonoBehaviour
{
    [SerializeField] private RuntimeToolService _tools;

    private void Awake()
    {
        if (_tools == null)
        {
            throw new InvalidOperationException("RuntimeToolService is required.");
        }
    }

    public JArray GetToolDefinitions()
    {
        return new JArray
        {
            Tool("scene.get_state", "Returns runtime objects, transforms, parents, scripts and supported components.", new JObject()),

            Tool(
                "scene.create_primitive",
                "Creates a Unity primitive and returns objectId.",
                new JObject
                {
                    ["primitiveType"] = StringProperty("Cube, Sphere, Capsule, Cylinder, Plane or Quad."),
                    ["name"] = StringProperty("Object name."),
                    ["x"] = NumberProperty("World X."),
                    ["y"] = NumberProperty("World Y."),
                    ["z"] = NumberProperty("World Z.")
                },
                "primitiveType", "name", "x", "y", "z"
            ),

            Tool(
                "scene.set_transform",
                "Changes position, rotation and/or scale.",
                new JObject
                {
                    ["id"] = StringProperty("Runtime object ID."),
                    ["position"] = Vector3Property("World position."),
                    ["rotation"] = Vector3Property("Euler rotation."),
                    ["scale"] = Vector3Property("Local scale.")
                },
                "id"
            ),

            Tool(
                "scene.set_parent",
                "Parents a runtime object under another runtime object. Empty parentId removes the parent.",
                new JObject
                {
                    ["childId"] = StringProperty("Child runtime object ID."),
                    ["parentId"] = StringProperty("Parent runtime object ID, or empty string to unparent.")
                },
                "childId", "parentId"
            ),

            Tool(
                "scene.delete_object",
                "Deletes a runtime object.",
                new JObject
                {
                    ["id"] = StringProperty("Runtime object ID.")
                },
                "id"
            ),

            Tool(
                "scene.save",
                "Saves the current runtime scene.",
                new JObject
                {
                    ["fileName"] = StringProperty("Scene filename.")
                },
                "fileName"
            ),

            Tool(
                "scene.load",
                "Loads a saved runtime scene.",
                new JObject
                {
                    ["fileName"] = StringProperty("Scene filename.")
                },
                "fileName"
            ),

            Tool("asset.list_models", "Lists exact GLB paths. Use instead of guessing model paths.", new JObject()),
            Tool("asset.list_textures", "Lists exact PNG paths. Use instead of guessing texture paths.", new JObject()),
            Tool("asset.list_audio", "Lists exact WAV paths. Use instead of guessing audio paths.", new JObject()),

            Tool(
                "asset.load_model",
                "Loads a GLB model and returns objectId.",
                new JObject
                {
                    ["path"] = StringProperty("Exact path returned by asset.list_models."),
                    ["name"] = StringProperty("Object name."),
                    ["x"] = NumberProperty("World X."),
                    ["y"] = NumberProperty("World Y."),
                    ["z"] = NumberProperty("World Z.")
                },
                "path", "name", "x", "y", "z"
            ),

            Tool(
                "asset.set_texture",
                "Applies a PNG texture to a runtime object.",
                new JObject
                {
                    ["id"] = StringProperty("Runtime object ID."),
                    ["path"] = StringProperty("Exact path returned by asset.list_textures.")
                },
                "id", "path"
            ),

            Tool(
                "asset.play_audio",
                "Loads a PCM 16-bit WAV, assigns it to AudioSource and plays it.",
                new JObject
                {
                    ["id"] = StringProperty("Runtime object ID."),
                    ["path"] = StringProperty("Exact path returned by asset.list_audio."),
                    ["loop"] = BoolProperty("Whether audio should loop."),
                    ["volume"] = NumberProperty("Volume from 0 to 1.")
                },
                "id", "path", "loop", "volume"
            ),

            Tool(
                "component.add",
                "Adds a whitelisted runtime component. Supported: Rigidbody, Light, AudioSource.",
                new JObject
                {
                    ["id"] = StringProperty("Runtime object ID."),
                    ["componentType"] = StringProperty("Rigidbody, Light or AudioSource.")
                },
                "id", "componentType"
            ),

            Tool(
                "component.set_property",
                "Sets a supported component property. Value is passed as text.",
                new JObject
                {
                    ["id"] = StringProperty("Runtime object ID."),
                    ["componentType"] = StringProperty("Rigidbody, Light or AudioSource."),
                    ["property"] = StringProperty("Property name."),
                    ["value"] = StringProperty("Value. Examples: 2.0, true, #FF0000.")
                },
                "id", "componentType", "property", "value"
            ),

            Tool(
                "script.create",
                "Creates or replaces a Lua script.",
                new JObject
                {
                    ["scriptName"] = StringProperty("Lua filename."),
                    ["source"] = StringProperty("Complete Lua source.")
                },
                "scriptName", "source"
            ),

            Tool(
                "script.attach",
                "Attaches an existing Lua script.",
                new JObject
                {
                    ["objectId"] = StringProperty("Runtime object ID."),
                    ["scriptName"] = StringProperty("Existing Lua filename.")
                },
                "objectId", "scriptName"
            ),

            Tool(
                "script.create_and_attach",
                "Creates a Lua script and immediately attaches it. Prefer this for new behaviours.",
                new JObject
                {
                    ["objectId"] = StringProperty("Runtime object ID."),
                    ["scriptName"] = StringProperty("Lua filename."),
                    ["source"] = StringProperty("Complete Lua source.")
                },
                "objectId", "scriptName", "source"
            ),

            Tool(
                "file.read",
                "Reads a text file inside the runtime sandbox.",
                new JObject
                {
                    ["path"] = StringProperty("Relative file path.")
                },
                "path"
            ),

            Tool(
                "file.write",
                "Writes a text file inside the runtime sandbox.",
                new JObject
                {
                    ["path"] = StringProperty("Relative file path."),
                    ["content"] = StringProperty("Complete contents.")
                },
                "path", "content"
            ),

            Tool(
                "file.find",
                "Finds files inside the runtime sandbox.",
                new JObject
                {
                    ["pattern"] = StringProperty("Pattern such as *.lua.")
                }
            )
        };
    }

    public async Task<JObject> CallAsync(string name, JObject arguments)
    {
        try
        {
            switch (name)
            {
                case "scene.get_state":
                    return Success(_tools.GetSceneState());

                case "scene.create_primitive":
                    {
                        string objectId = _tools.CreatePrimitive(
                            RequireString(arguments, "primitiveType"),
                            RequireString(arguments, "name"),
                            RequireFloat(arguments, "x"),
                            RequireFloat(arguments, "y"),
                            RequireFloat(arguments, "z")
                        );

                        return SuccessJson(new JObject
                        {
                            ["success"] = true,
                            ["objectId"] = objectId
                        });
                    }

                case "scene.set_transform":
                    {
                        string id = RequireString(arguments, "id");

                        if (arguments["position"] is JObject position)
                        {
                            _tools.SetPosition(id, RequireFloat(position, "x"), RequireFloat(position, "y"), RequireFloat(position, "z"));
                        }

                        if (arguments["rotation"] is JObject rotation)
                        {
                            _tools.SetRotation(id, RequireFloat(rotation, "x"), RequireFloat(rotation, "y"), RequireFloat(rotation, "z"));
                        }

                        if (arguments["scale"] is JObject scale)
                        {
                            _tools.SetScale(id, RequireFloat(scale, "x"), RequireFloat(scale, "y"), RequireFloat(scale, "z"));
                        }

                        return SuccessJson(new JObject
                        {
                            ["success"] = true,
                            ["objectId"] = id
                        });
                    }

                case "scene.set_parent":
                    {
                        string childId = RequireString(arguments, "childId");
                        string parentId = arguments.Value<string>("parentId") ?? "";

                        _tools.SetParent(childId, parentId);

                        return SuccessJson(new JObject
                        {
                            ["success"] = true,
                            ["childId"] = childId,
                            ["parentId"] = parentId
                        });
                    }

                case "scene.delete_object":
                    {
                        string id = RequireString(arguments, "id");

                        _tools.DestroyObject(id);

                        return SuccessJson(new JObject
                        {
                            ["success"] = true,
                            ["objectId"] = id,
                            ["deleted"] = true
                        });
                    }

                case "scene.save":
                    {
                        string fileName = RequireString(arguments, "fileName");
                        string path = _tools.SaveScene(fileName);

                        return SuccessJson(new JObject
                        {
                            ["success"] = true,
                            ["fileName"] = fileName,
                            ["path"] = path
                        });
                    }

                case "scene.load":
                    {
                        string fileName = RequireString(arguments, "fileName");

                        await _tools.LoadScene(fileName);

                        return SuccessJson(new JObject
                        {
                            ["success"] = true,
                            ["fileName"] = fileName
                        });
                    }

                case "asset.list_models":
                    return SuccessJson(new JObject
                    {
                        ["success"] = true,
                        ["models"] = JArray.FromObject(_tools.ListModels())
                    });

                case "asset.list_textures":
                    return SuccessJson(new JObject
                    {
                        ["success"] = true,
                        ["textures"] = JArray.FromObject(_tools.ListTextures())
                    });

                case "asset.list_audio":
                    return SuccessJson(new JObject
                    {
                        ["success"] = true,
                        ["audio"] = JArray.FromObject(_tools.ListAudio())
                    });

                case "asset.load_model":
                    {
                        try
                        {
                            string objectId = await _tools.LoadModel(
                                RequireString(arguments, "path"),
                                RequireString(arguments, "name"),
                                RequireFloat(arguments, "x"),
                                RequireFloat(arguments, "y"),
                                RequireFloat(arguments, "z")
                            );

                            return SuccessJson(new JObject
                            {
                                ["success"] = true,
                                ["objectId"] = objectId
                            });
                        }
                        catch (FileNotFoundException e)
                        {
                            return ErrorJson(new JObject
                            {
                                ["success"] = false,
                                ["error"] = e.Message,
                                ["availableModels"] = JArray.FromObject(_tools.ListModels())
                            });
                        }
                    }

                case "asset.set_texture":
                    {
                        try
                        {
                            string id = RequireString(arguments, "id");
                            string path = RequireString(arguments, "path");

                            _tools.SetTexture(id, path);

                            return SuccessJson(new JObject
                            {
                                ["success"] = true,
                                ["objectId"] = id,
                                ["texture"] = path
                            });
                        }
                        catch (FileNotFoundException e)
                        {
                            return ErrorJson(new JObject
                            {
                                ["success"] = false,
                                ["error"] = e.Message,
                                ["availableTextures"] = JArray.FromObject(_tools.ListTextures())
                            });
                        }
                    }

                case "asset.play_audio":
                    {
                        try
                        {
                            string id = RequireString(arguments, "id");
                            string path = RequireString(arguments, "path");

                            _tools.PlayAudio(
                                id,
                                path,
                                RequireBool(arguments, "loop"),
                                RequireFloat(arguments, "volume")
                            );

                            return SuccessJson(new JObject
                            {
                                ["success"] = true,
                                ["objectId"] = id,
                                ["audio"] = path
                            });
                        }
                        catch (FileNotFoundException e)
                        {
                            return ErrorJson(new JObject
                            {
                                ["success"] = false,
                                ["error"] = e.Message,
                                ["availableAudio"] = JArray.FromObject(_tools.ListAudio())
                            });
                        }
                    }

                case "component.add":
                    {
                        string id = RequireString(arguments, "id");
                        string component = _tools.AddComponent(
                            id,
                            RequireString(arguments, "componentType")
                        );

                        return SuccessJson(new JObject
                        {
                            ["success"] = true,
                            ["objectId"] = id,
                            ["component"] = component
                        });
                    }

                case "component.set_property":
                    {
                        string id = RequireString(arguments, "id");

                        _tools.SetComponentProperty(
                            id,
                            RequireString(arguments, "componentType"),
                            RequireString(arguments, "property"),
                            RequireString(arguments, "value")
                        );

                        return SuccessJson(new JObject
                        {
                            ["success"] = true,
                            ["objectId"] = id
                        });
                    }

                case "script.create":
                    {
                        string scriptName = RequireString(arguments, "scriptName");

                        _tools.CreateScript(
                            scriptName,
                            RequireString(arguments, "source")
                        );

                        return SuccessJson(new JObject
                        {
                            ["success"] = true,
                            ["scriptName"] = NormalizeScriptName(scriptName),
                            ["created"] = true
                        });
                    }

                case "script.attach":
                    {
                        string objectId = RequireString(arguments, "objectId");
                        string scriptName = RequireString(arguments, "scriptName");

                        _tools.AttachScript(objectId, scriptName);

                        return SuccessJson(new JObject
                        {
                            ["success"] = true,
                            ["objectId"] = objectId,
                            ["scriptName"] = NormalizeScriptName(scriptName),
                            ["attached"] = true
                        });
                    }

                case "script.create_and_attach":
                    {
                        string objectId = RequireString(arguments, "objectId");
                        string scriptName = RequireString(arguments, "scriptName");

                        _tools.CreateAndAttachScript(
                            objectId,
                            scriptName,
                            RequireString(arguments, "source")
                        );

                        return SuccessJson(new JObject
                        {
                            ["success"] = true,
                            ["objectId"] = objectId,
                            ["scriptName"] = NormalizeScriptName(scriptName),
                            ["created"] = true,
                            ["attached"] = true
                        });
                    }

                case "file.read":
                    return Success(
                        _tools.ReadFile(
                            RequireString(arguments, "path")
                        )
                    );

                case "file.write":
                    {
                        string path = RequireString(arguments, "path");

                        _tools.WriteFile(
                            path,
                            RequireString(arguments, "content")
                        );

                        return SuccessJson(new JObject
                        {
                            ["success"] = true,
                            ["path"] = path
                        });
                    }

                case "file.find":
                    {
                        string pattern = arguments.Value<string>("pattern");

                        if (string.IsNullOrWhiteSpace(pattern))
                        {
                            pattern = "*";
                        }

                        return SuccessJson(new JObject
                        {
                            ["success"] = true,
                            ["files"] = JArray.FromObject(_tools.FindFiles(pattern))
                        });
                    }

                default:
                    return Error($"Unknown tool: {name}");
            }
        }
        catch (Exception e)
        {
            return Error(e.Message);
        }
    }

    private static JObject Tool(string name, string description, JObject properties, params string[] required)
    {
        JObject schema = new JObject
        {
            ["type"] = "object",
            ["properties"] = properties,
            ["additionalProperties"] = false
        };

        if (required != null && required.Length > 0)
        {
            schema["required"] = new JArray(required);
        }

        return new JObject
        {
            ["name"] = name,
            ["description"] = description,
            ["inputSchema"] = schema
        };
    }

    private static JObject StringProperty(string description)
    {
        return new JObject
        {
            ["type"] = "string",
            ["description"] = description
        };
    }

    private static JObject NumberProperty(string description)
    {
        return new JObject
        {
            ["type"] = "number",
            ["description"] = description
        };
    }

    private static JObject BoolProperty(string description)
    {
        return new JObject
        {
            ["type"] = "boolean",
            ["description"] = description
        };
    }

    private static JObject Vector3Property(string description)
    {
        return new JObject
        {
            ["type"] = "object",
            ["description"] = description,
            ["properties"] = new JObject
            {
                ["x"] = NumberProperty("X"),
                ["y"] = NumberProperty("Y"),
                ["z"] = NumberProperty("Z")
            },
            ["required"] = new JArray("x", "y", "z"),
            ["additionalProperties"] = false
        };
    }

    private static string RequireString(JObject arguments, string name)
    {
        JToken token = arguments[name];

        if (token == null ||
            token.Type != JTokenType.String ||
            string.IsNullOrWhiteSpace(token.Value<string>()))
        {
            throw new ArgumentException($"Missing or invalid string argument '{name}'.");
        }

        return token.Value<string>();
    }

    private static float RequireFloat(JObject arguments, string name)
    {
        JToken token = arguments[name];

        if (token == null ||
            (token.Type != JTokenType.Float &&
             token.Type != JTokenType.Integer))
        {
            throw new ArgumentException($"Missing or invalid number argument '{name}'.");
        }

        return token.Value<float>();
    }

    private static bool RequireBool(JObject arguments, string name)
    {
        JToken token = arguments[name];

        if (token == null || token.Type != JTokenType.Boolean)
        {
            throw new ArgumentException($"Missing or invalid boolean argument '{name}'.");
        }

        return token.Value<bool>();
    }

    private static JObject Success(string text)
    {
        return new JObject
        {
            ["content"] = new JArray
            {
                new JObject
                {
                    ["type"] = "text",
                    ["text"] = text
                }
            },
            ["isError"] = false
        };
    }

    private static JObject SuccessJson(JObject value)
    {
        return Success(
            value.ToString(Formatting.None)
        );
    }

    private static JObject Error(string text)
    {
        return ErrorJson(
            new JObject
            {
                ["success"] = false,
                ["error"] = text
            }
        );
    }

    private static JObject ErrorJson(JObject value)
    {
        return new JObject
        {
            ["content"] = new JArray
            {
                new JObject
                {
                    ["type"] = "text",
                    ["text"] = value.ToString(Formatting.None)
                }
            },
            ["isError"] = true
        };
    }

    private static string NormalizeScriptName(string scriptName)
    {
        return scriptName.EndsWith(".lua", StringComparison.OrdinalIgnoreCase)
            ? scriptName
            : scriptName + ".lua";
    }
}